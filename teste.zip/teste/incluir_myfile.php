<?php
include ('config.php');
?>

<!DOCTYPE html>
<html>
    </head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, intial-scale=1.0"/>
    

</head>


</body> 

 


<div class="container main" >
    <div class"image-box">
        
        <form action="php/codigo_total7082.php" method="post" name="upfrm" enctype="multipart/form-data">
            </div>
    
      <p></strong>FOTO:</strong>
          <input type="file" name="myfile" id="myfile" class="file_input"/> </p>
      
                          
            <div class="">
              <input type="submit" name="Submit" value="Submeter" class="btn">
              </div>
              </form>
        
    </div>
    </div>

    </body>
    </html>